package com.xxx.generator.excel;

import com.xxx.generator.model.RepositoryInfo;
import com.xxx.generator.model.TypeInfo;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import java.io.IOException;
import java.io.OutputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;

public class ExcelWriter {

    private final ExcelTreeBuilder treeBuilder = new ExcelTreeBuilder();

    public void write(Path outputPath, RepositoryInfo repository, List<TypeInfo> types) throws IOException {
        if (outputPath.getParent() != null) {
            Files.createDirectories(outputPath.getParent());
        }

        List<ExcelTreeRow> rows = treeBuilder.build(repository, types);

        try (Workbook workbook = new XSSFWorkbook()) {
            writeRepositorySheet(workbook, repository, rows);

            try (OutputStream outputStream = Files.newOutputStream(outputPath)) {
                workbook.write(outputStream);
            }
        }
    }

    private void writeRepositorySheet(Workbook workbook, RepositoryInfo repository, List<ExcelTreeRow> rows) {
        Sheet sheet = workbook.createSheet("Repository");
        createHeader(sheet.createRow(0));

        Row repositoryRow = sheet.createRow(1);
        repositoryRow.createCell(0).setCellValue("Repository");
        repositoryRow.createCell(2).setCellValue(ExcelNames.logicalName(repository.javadoc(), repository.name()));
        repositoryRow.createCell(4).setCellValue(repository.name());

        int rowIndex = 2;
        for (ExcelTreeRow treeRow : rows) {
            if (treeRow.logicalName().isBlank() && treeRow.section().isBlank()) {
                sheet.createRow(rowIndex++);
                continue;
            }
            writeTreeRow(sheet.createRow(rowIndex++), treeRow);
        }
    }

    private void createHeader(Row row) {
        row.createCell(0).setCellValue("区分");
        row.createCell(1).setCellValue("項番");
        row.createCell(2).setCellValue("論理項目名");
        row.createCell(3).setCellValue("物理項目名(SQL)");
        row.createCell(4).setCellValue("物理項目名");
        row.createCell(5).setCellValue("DB型");
        row.createCell(6).setCellValue("Java型");
        row.createCell(7).setCellValue("備考");
    }

    private void writeTreeRow(Row row, ExcelTreeRow treeRow) {
        row.createCell(0).setCellValue(treeRow.section());
        if (treeRow.no() > 0) {
            row.createCell(1).setCellValue(treeRow.no());
        }
        row.createCell(2).setCellValue(treeRow.logicalName());
        row.createCell(3).setCellValue(treeRow.sqlPhysicalName());
        row.createCell(4).setCellValue(treeRow.physicalName());
        row.createCell(5).setCellValue(treeRow.dbType());
        row.createCell(6).setCellValue(treeRow.javaType());
        row.createCell(7).setCellValue(treeRow.note());
    }
}
