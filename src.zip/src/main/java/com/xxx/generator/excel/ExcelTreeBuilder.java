package com.xxx.generator.excel;

import com.xxx.generator.model.FieldInfo;
import com.xxx.generator.model.MethodInfo;
import com.xxx.generator.model.RepositoryInfo;
import com.xxx.generator.model.TypeInfo;
import com.xxx.generator.parser.TypeReferenceExtractor;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

public class ExcelTreeBuilder {

    private static final String INDENT = "  ";

    private final TypeReferenceExtractor typeReferenceExtractor = new TypeReferenceExtractor();

    public List<ExcelTreeRow> build(RepositoryInfo repository, List<TypeInfo> types) {
        Map<String, TypeInfo> typeMap = new LinkedHashMap<>();
        for (TypeInfo type : types) {
            typeMap.putIfAbsent(type.name(), type);
        }

        List<ExcelTreeRow> rows = new ArrayList<>();
        for (MethodInfo method : repository.methods()) {
            rows.addAll(buildMethodRows(method, typeMap));
        }
        return rows;
    }

    private List<ExcelTreeRow> buildMethodRows(MethodInfo method, Map<String, TypeInfo> typeMap) {
        List<ExcelTreeRow> rows = new ArrayList<>();
        int itemNumber = 1;

        rows.add(new ExcelTreeRow(
                "Method",
                itemNumber++,
                ExcelNames.logicalName(method.javadoc(), method.name()),
                "",
                method.name(),
                "",
                "",
                ""
        ));
        rows.add(new ExcelTreeRow(
                "SQL概要",
                itemNumber++,
                ExcelNames.logicalName(method.javadoc(), method.name()),
                "",
                "",
                "",
                "",
                ""
        ));

        if (!method.inputTypes().isEmpty()) {
            rows.add(new ExcelTreeRow("INPUT", itemNumber++, "INPUT", "", "", "", "", ""));
            for (String inputType : method.inputTypes()) {
                itemNumber = appendTypeTree(rows, inputType, inputType, 1, itemNumber, typeMap, new HashSet<>());
            }
        }

        if (!method.outputTypes().isEmpty()) {
            rows.add(new ExcelTreeRow("OUTPUT", itemNumber++, "OUTPUT", "", "", "", "", ""));
            for (String outputType : method.outputTypes()) {
                itemNumber = appendTypeTree(rows, outputType, outputType, 1, itemNumber, typeMap, new HashSet<>());
            }
        }

        rows.add(ExcelTreeRow.blank());
        return rows;
    }

    private int appendTypeTree(List<ExcelTreeRow> rows,
                               String displayTypeName,
                               String javaType,
                               int depth,
                               int itemNumber,
                               Map<String, TypeInfo> typeMap,
                               Set<String> visited) {
        if (typeReferenceExtractor.isBuiltinType(displayTypeName)) {
            rows.add(createRow(itemNumber++, depth, "", displayTypeName, javaType));
            return itemNumber;
        }

        TypeInfo typeInfo = typeMap.get(displayTypeName);
        if (typeInfo == null) {
            rows.add(createRow(itemNumber++, depth, "", displayTypeName, javaType));
            return itemNumber;
        }

        if (visited.contains(typeInfo.name())) {
            rows.add(createRow(itemNumber++, depth, typeInfo.javadoc(), typeInfo.name(), javaType));
            return itemNumber;
        }
        visited.add(typeInfo.name());

        rows.add(createRow(itemNumber++, depth, typeInfo.javadoc(), typeInfo.name(), javaType));
        for (FieldInfo field : typeInfo.fields()) {
            rows.add(createRow(itemNumber++, depth + 1, field.javadoc(), field.name(), field.type()));
            itemNumber = appendNestedFieldTypes(rows, field, depth + 2, itemNumber, typeMap, visited);
        }

        visited.remove(typeInfo.name());
        return itemNumber;
    }

    private int appendNestedFieldTypes(List<ExcelTreeRow> rows,
                                       FieldInfo field,
                                       int depth,
                                       int itemNumber,
                                       Map<String, TypeInfo> typeMap,
                                       Set<String> visited) {
        for (String nestedTypeName : typeReferenceExtractor.extractFromTypeName(field.type())) {
            if (typeReferenceExtractor.isBuiltinType(nestedTypeName)) {
                continue;
            }
            if (!typeMap.containsKey(nestedTypeName)) {
                continue;
            }
            if (visited.contains(nestedTypeName)) {
                continue;
            }
            itemNumber = appendTypeFieldsOnly(rows, typeMap.get(nestedTypeName), depth, itemNumber, typeMap, visited);
        }
        return itemNumber;
    }

    private int appendTypeFieldsOnly(List<ExcelTreeRow> rows,
                                     TypeInfo typeInfo,
                                     int depth,
                                     int itemNumber,
                                     Map<String, TypeInfo> typeMap,
                                     Set<String> visited) {
        visited.add(typeInfo.name());
        for (FieldInfo field : typeInfo.fields()) {
            rows.add(createRow(itemNumber++, depth, field.javadoc(), field.name(), field.type()));
            itemNumber = appendNestedFieldTypes(rows, field, depth + 1, itemNumber, typeMap, visited);
        }
        visited.remove(typeInfo.name());
        return itemNumber;
    }

    private ExcelTreeRow createRow(int no,
                                   int depth,
                                   String javadoc,
                                   String physicalName,
                                   String javaType) {
        return new ExcelTreeRow(
                "",
                no,
                indent(ExcelNames.logicalName(javadoc, physicalName), depth),
                "",
                physicalName,
                "",
                javaType,
                ""
        );
    }

    private String indent(String text, int depth) {
        return INDENT.repeat(Math.max(0, depth)) + text;
    }
}
